﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{

    public GameObject player;

    private Vector3 offset;
    public float smoothSpeed = 0.125f;
    public float minHeight = -50f;  // Au plus bas 
    public bool followY = false;
    public float addY = 50f;
    public float addX = 15f;

    // Use this for initialization
    void Start ()
    {
        offset = transform.position - player.transform.position;
	}
	
	// Late Update is called once per frame after every item has been processed in Update
	void FixedUpdate ()
    {
        Vector3 v;
        if ( followY )
        {
            float x;
            if (player.GetComponent<CharacterController2D>().FacingRight)
            {
                x = addX;
            } else {
                x = -addX;
            }
            v = new Vector3( player.transform.position.x + x, player.transform.position.y + addY, 0f );
        } else
        {
            v = new Vector3(player.transform.position.x, 0f, 0f);
        }
        Vector3 desiredPosition = v + offset;
        Vector3 smoothedPosition = Vector3.Lerp (transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;

        //transform.LookAt(player.transform);
	}
}
