﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ChgLvlInteraction : MonoBehaviour
{

    public GameObject currentInterObj = null;
    public string lvl;
    public GameObject id = null;
    public GameObject Warning;
    void Start(){
        Warning.SetActive(false);
    }

    void OnTriggerStay2D(Collider2D other){

        Debug.Log("Je suis rentrer");
        if(other.CompareTag("door") && id.name==other.name){
            Warning.SetActive(true);
            currentInterObj = other.gameObject;

            if(Input.GetKeyDown (KeyCode.E)){
                Debug.Log("Enter!");
                SceneManager.LoadScene(lvl);
            }
        }
    }
    void OnTriggerExit2D(Collider2D other){

    if(other.CompareTag ("door")){
           if(other.gameObject == currentInterObj){
                currentInterObj = null;
                Warning.SetActive(false);
            }
        }    
        

    }
}
