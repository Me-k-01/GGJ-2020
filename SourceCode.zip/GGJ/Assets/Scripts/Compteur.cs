﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Compteur : MonoBehaviour
{

    public GameObject background;
    public GameObject fog;
    public GameObject graveStone;

    private int keyCount = 0;  // compteur de clef
    public int keyToObtain = 3;

    private float deathCount = 0f;


    private int i = 0;
    public Color[] levelStyle = { new Color(1, 1, 1, 1), new Color(1, 0.8f, 0.3f, 1), new Color(1, 0.4f, 0.8f, 1) };

    [SerializeField] private Transform teleport;
    public string lvl;
    // Update is called once per frame
    void Update()
    {

    }
    private void OnTriggerEnter2D(Collider2D other) // Lorsque 
    {
        Debug.Log(other.tag);
        //Interaction collision
        if (other.tag == "Key") // Si c'est une clef
        {
            keyCount++;
            Destroy(other.gameObject); // Destruction de la clef
            if (keyCount >= keyToObtain)
            {
                keyCount = 0; // le compteur repasse à zero pour le niveau suivant
                if (i >= levelStyle.Length - 1)
                {
                    i = 0;
                }
                else {  // On fait gaffe au erreur de taille du tableau
                    background.GetComponent<SpriteRenderer>().color = levelStyle[i];

                } 

                i++; // niveau suivant

                // TODO: reussite du niveau.
            }
        }
        if (other.tag == "Outside")
        {

            gameObject.transform.position = teleport.position + new Vector3(20f, 20f, 0f);
            deathCount++;
            if (deathCount < 10)
            {
                fog.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, deathCount / 10);

            }
        }
        if (other.tag == "Ennemy") // Si c'est un ennemy
        {
            Instantiate(graveStone, gameObject.transform.position, Quaternion.identity);
            gameObject.transform.position = teleport.position;
            deathCount++;
            if (deathCount<10)
            {

                fog.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, deathCount / 10);

            }

        }
        if (other.tag == "Kiosque")
        {
            SceneManager.LoadScene(lvl);
        }

        if (other.tag == "PNJ")
        {

        }
    }
}
