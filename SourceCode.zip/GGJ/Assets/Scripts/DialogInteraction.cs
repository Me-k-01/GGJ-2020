﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Pour Interactions dialogue
public class DialogInteraction : MonoBehaviour
{
    public GameObject currentInterObj = null;

    public GameObject id = null;
    //Optionelle 
    //Faire une image qui montre qur quelle bouton appuyer
    public GameObject typeInteract;


    void Start(){
        typeInteract.SetActive(false);

    }
    void OnTriggerEnter2D(Collider2D other){

        if(other.CompareTag ("interactObj") && id.name==other.name){
            Debug.Log (other.name);
            currentInterObj = other.gameObject;
            typeInteract.SetActive(true);
        }

    }
    void OnTriggerExit2D(Collider2D other){

        if(other.CompareTag ("interactObj")){
            if(other.gameObject == currentInterObj){
                currentInterObj = null;
                typeInteract.SetActive(false);
            }
        }
    }
}
