﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    [SerializeField]


    public GameObject bullet;
    public Transform player;
    public float radius = 50f;
    public bool isAttacking = false;

    private bool FacingRight = false;
    public float fireRate = 3f;
    private float nextFire;

    void Start()
    {
        nextFire = Time.time;

    }

    void Update()
    {
        CheckForAttack();
        CheckIfTimeToFire();
    }
    

    void CheckForAttack(){

            if(Mathf.Abs(player.position.x - gameObject.transform.position.x) < radius ){

                isAttacking = true;
                
            } else {isAttacking = false;}

            if (player.position.x > gameObject.transform.position.x && !FacingRight)
            {
                Flip();
            }
            if (player.position.x < gameObject.transform.position.x && FacingRight)
            {
                Flip();
            }
            

    }
    void CheckIfTimeToFire(){
        if(Time.time > nextFire && isAttacking ){

            float xOffset;

            if (FacingRight)
            {
                xOffset = 2f;
            }
            else
            {
                xOffset = -2f;
            }
            
            Instantiate(bullet, new Vector2(gameObject.transform.position.x+ xOffset, gameObject.transform.position.y+0.5f), Quaternion.identity);
            nextFire = Time.time + fireRate;

        }

    }
    void Flip()
    {
        FacingRight = !FacingRight;

        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }


}
