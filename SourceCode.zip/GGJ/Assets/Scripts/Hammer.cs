﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hammer : MonoBehaviour
{

    [SerializeField]
    private float moveSpeed = 30f;
    private Rigidbody2D rb;
    private CharacterController2D target;
    private Vector2 moveDirection;
    public float lifeTime = 2f;


    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        if (GameObject.FindObjectOfType<CharacterController2D>().FacingRight)
        {
            rb.velocity = new Vector2(moveSpeed, 0f);

        }
        else
        {
            rb.velocity = new Vector2(-moveSpeed, 0f);
        }
        Destroy(gameObject, lifeTime);



    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "Ennemy")
        {
            Destroy(collision.gameObject);
        }
    }

}
