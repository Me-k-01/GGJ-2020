﻿using System.Collections;

using System.Collections.Generic;

using UnityEngine;



public class PlayerMovement : MonoBehaviour
{



    public CharacterController2D controller;

    public GameObject throwingItem;

    public bool canAttack = false;
    public bool camAim = true;

    public float runSpeed = 40f;

    public float fireRate = 3f;
    private float nextFire;



    float horizontalMove = 0f;

    bool jump = false;



    // Update is called once per frame
    private void Start()
    {

        nextFire = Time.time;
    }
    void Update()
    {
        

        horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

        if (canAttack && ( Input.GetMouseButton(0) || Input.GetAxisRaw("Vertical") == -1))
        {   
            if ( CheckIfTimeToFire())
            {

                float xOffset;
                if (controller.FacingRight)
                {
                    xOffset = 10f;
                }
                else
                {
                    xOffset = -10f;
                }
                if (!camAim)
                {
                    Instantiate(throwingItem, new Vector2(gameObject.transform.position.x + xOffset, gameObject.transform.position.y + 1f), Quaternion.identity);


                }
            }
        }
        

        if (Input.GetButtonDown("Jump") )

        {

            jump = true;

        }


    }
    bool CheckIfTimeToFire()
    {
        if (Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            return true;
        } else
        {
            return false;
        }

    }


    private void OnCollisionEnter2D(Collision2D collision)
    {

        if (collision.gameObject.tag == "PNJ")
        {
            Physics2D.IgnoreCollision(gameObject.GetComponent<Collider2D>(), collision.collider);
        }
        if (collision.gameObject.tag == "Gravestone")
        {
            Physics2D.IgnoreCollision(gameObject.GetComponent<Collider2D>(), collision.collider);
        }
    }

    void FixedUpdate()

    {

        // Move our character

        controller.Move(horizontalMove * Time.fixedDeltaTime, jump);

        jump = false;

    }
    
}