﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shoot : MonoBehaviour
{
    [SerializeField]
    private float moveSpeed = 30f;
    // Timer
    public float lifeTime = 1.5f;
    private Rigidbody2D rb;
    private Vector3 target;
    private Vector2 moveDirection;
    

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        target = GameObject.FindObjectOfType<CharacterController2D>().transform.position;

        target = new Vector3(target.x, target.y+3f, target.z);
        moveDirection = (target - transform.position).normalized * moveSpeed;
        rb.velocity = new Vector2(moveDirection.x, moveDirection.y);

        var relPos = target - gameObject.transform.position;
        var ang = Mathf.Atan2(relPos.y, relPos.x) * Mathf.Rad2Deg;
        var rotation = Quaternion.AngleAxis(ang, Vector3.forward);
        gameObject.transform.rotation = rotation;

        Destroy(gameObject, lifeTime);

    }
    private void Update()
    {

    }


}
