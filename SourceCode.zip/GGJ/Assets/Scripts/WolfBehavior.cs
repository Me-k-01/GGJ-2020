﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WolfBehavior : MonoBehaviour {
    
    public GameObject player;
    public Animator animator;
    public bool chassing = true;
    public float speed = 700f;
    
    public float detectionRadius = 35f;

    private Rigidbody2D m_Rigidbody2D;
    [Range(0, .3f)] [SerializeField] private float m_MovementSmoothing = .05f;	// How much to smooth out the movement
    private bool m_FacingRight = false;  // For determining which way the player is currently facing.
    private Vector3 m_Velocity = Vector3.zero;

    // Use this for initialization
    void Start () {

    }
    private void Awake()
    {
        m_Rigidbody2D = GetComponent<Rigidbody2D>();
        

    }

    // Update is called once per frame
    void Update () {
        float vx = 0f;


        if ( Mathf.Abs( player.transform.position.x - gameObject.transform.position.x ) < detectionRadius )
        {
            chassing = true;
        } else
        {
            chassing = false;
        }


        if (chassing)
        {
            if ( player.transform.position.x > gameObject.transform.position.x )
            {
                vx += speed * 2;
            }
            if (player.transform.position.x < gameObject.transform.position.x)
            {
                vx -= speed * 2;
            }

            if ( vx > 0 && !m_FacingRight)
            {
                Flip();
            } else if (vx < 0 && m_FacingRight)
            {
                Flip();
            }

            // Move the character by finding the target velocity
            Vector3 targetVelocity = new Vector2(vx * Time.fixedDeltaTime, m_Rigidbody2D.velocity.y);
            // And then smoothing it out and applying it to the character
            m_Rigidbody2D.velocity = Vector3.SmoothDamp(m_Rigidbody2D.velocity, targetVelocity, ref m_Velocity, m_MovementSmoothing);

        }
        animator.SetFloat("Speed", Mathf.Abs(m_Rigidbody2D.velocity.x));

    }
    private void Flip()
    {
        // Switch the way the player is labelled as facing.
        m_FacingRight = !m_FacingRight;

        // Multiply the player's x local scale by -1.
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}
