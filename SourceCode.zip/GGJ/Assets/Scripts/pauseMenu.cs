﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class pauseMenu: MonoBehaviour
{

    public static bool GameIsPaused = false;
 
     public GameObject PauseMenuBehavior;

    private void Start()
    {
        PauseMenuBehavior.SetActive(false);
    }

    void Update()
     {
         if (Input.GetKeyDown(KeyCode.P) || Input.GetKeyDown(KeyCode.Escape))
         {
             if (GameIsPaused)
             {
                 Resume();
             }
             else
             {
                 Pause();
             }
         }
     }
     public void Resume()
     {
         PauseMenuBehavior.SetActive(false);
         Time.timeScale = 1f;
         GameIsPaused = false;
     }
     void Pause()
     {
         PauseMenuBehavior.SetActive(true);
         Time.timeScale = 0f;
         GameIsPaused = true;
     }
    public void MainMenu()
     {
         Time.timeScale = 1f;
         SceneManager.LoadScene("Main_Menu");
     }
     public void QuitGame()
     {
         Application.Quit();
         Debug.Log("Quitting game...");
     }
}
